import "./footer.css"

export default function Footer() {
  return (
    <footer>
			<div class="max-width">
				<h2>©Weniv Corp.</h2>
				<button class="top-button">TOP</button>
			</div>
		</footer>
  )
}
