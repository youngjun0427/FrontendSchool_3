import React from 'react'

export default function FailLoadData() {
  return (
    <div>서버에 오류가 발생했습니다. 문제가 계속되면 관리자에게 문의를 주십시오. 관리자 연락처......</div>
  )
}
